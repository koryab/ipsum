from setuptools import setup

setup(
    name='ipsum',
    version='0.0.1',
    packages=['ipsum'],
    install_requires=[
        'importlib; python_version == "3.8.5"',
    ],
)